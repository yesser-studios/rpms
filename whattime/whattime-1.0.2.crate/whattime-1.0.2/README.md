# whattime
Shows your current time right from the terminal.

## Usage
```
whattime
```
This will print out the current time in the HH:MM:SS format.